<?php
namespace LR\Otp\Admin;
/**
 * Shortcode handler class
 */
class LrotpDashboardShortcode {
    /**
     * Initializes the class
     */
    function __construct() {
        add_shortcode( 'lr-otp', [ $this, 'dashboard_shortcode' ] );
        
    }

    /**
     * Shortcode handler class
     *
     * @param  array $atts
     * @param  string $content
     *
     * @return string
     */
    public function dashboard_shortcode( $atts, $content = '' ) {
        wp_enqueue_script( 'lrotp-admin-script' );
        wp_enqueue_style( 'lrotp-admin-style' );

        return '<div class="lrotp-dashboard">Hello from Shortcode</div>';
    }
}