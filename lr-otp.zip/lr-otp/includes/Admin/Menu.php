<?php
namespace LR\Otp\Admin;
/**
 * The admin class
 */
class Menu {
    /**
     * Initialize the class
     */
    function __construct() {
        add_action( 'admin_menu', [ $this, 'admin_menu' ] );
    }

    /**
     * Register admin menu
     *
     * @return void
     */
    public function admin_menu() {
        add_menu_page( __( 'LR OTP', 'lr-otp' ), __( 'LR OTP', 'lr-otp' ), 'manage_options', 'lr-otp', [ $this, 'lrotp_dashboard_page' ], 'dashicons-shield' );
        add_submenu_page( 'lr-otp', 'Settings', 'Settings', 'manage_options', 'lrotp-settings', [ $this, 'lrotp_settings_page' ] );

    }
    /**
     * Render the Dashboard page
     *
     * @return void
     */
    public function lrotp_dashboard_page() {
        wp_enqueue_script( 'lrotp-admin-script' );
        wp_enqueue_style( 'lrotp-admin-style' );
        echo '<div class="wrap">';
        require_once LR_OTP_PLUGIN_DIR . 'includes/Admin/views/otp_dashboard.php';
        echo '</div>';
        }
    
    /**
     * Render the Settings page
     *
     * @return void
     */
    public function lrotp_settings_page() {
        wp_enqueue_script( 'lrotp-admin-script' );
        wp_enqueue_style( 'lrotp-admin-style' );
        echo '<div class="wrap">';
        require_once LR_OTP_PLUGIN_DIR . 'includes/Admin/views/otp_settings.php';
        echo '</div>';
        }

}