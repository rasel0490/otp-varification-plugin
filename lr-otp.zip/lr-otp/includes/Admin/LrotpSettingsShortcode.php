<?php
namespace LR\Otp\Admin;
/**
 * Shortcode handler class
 */
class LrotpSettingsShortcode {
    /**
     * Initializes the class
     */
    function __construct() {
        add_shortcode( 'lr-setting', [ $this, 'setting_shortcode' ] );
        
    }

    /**
     * Shortcode handler class
     *
     * @param  array $atts
     * @param  string $content
     *
     * @return string
     */
    public function setting_shortcode( $atts, $content = '' ) {
        wp_enqueue_script( 'lrotp-script' );
        //wp_enqueue_style( 'gold-style' );
        wp_enqueue_style( 'lrotp-admin-style' );

        return '<div class="lrotp-setting">Hello from Shortcode</div>';
    }
}