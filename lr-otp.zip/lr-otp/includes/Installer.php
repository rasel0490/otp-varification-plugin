<?php
namespace LR\Otp;

/**
 * Installer class
 */
class Installer {
        /**
     * Run the installer
     *
     * @return void
     */
    public function run() {
        $this->add_version();
        //$this->create_vendor_role();
        $this->create_tables();
        //$this->create_pages();

    }
    /**
     * Add time and version on DB
     */
    public function add_version() {
        $installed = get_option( 'lr_otp_installed' );

            if ( ! $installed ) {
                update_option( 'lr_otp_installed', time() );
            }

            update_option( 'lr_otp_version', LR_OTP_VERSION );
        
    }
    /**
     * Create necessary database tables
     *
     * @return void
     */
    public function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $lr_otp_table = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}lrotp` (
            `lrotp_id` int(11) NOT NULL AUTO_INCREMENT,
            `otp_name` varchar(255) NOT NULL,
            `otp_code` int(255) NOT NULL,
            PRIMARY KEY (`lrotp_id`)
           )  $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $lr_otp_table );

    }

}