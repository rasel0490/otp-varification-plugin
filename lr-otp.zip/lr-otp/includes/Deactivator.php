<?php
namespace LR\Otp;

/**
 * Deactivator class
 */
class Deactivator {
      /**
     * Run the Deactivator
     *
     * @return void
     */
    public function uninstall() {
        $this->delete_items();
        $this->delete_tables();
        //$this->delete_pages();

    }
    /**
     * Add time and version on DB
     */
    public function delete_items() {
        $uninstalled = 'wporg_option';
        delete_option($uninstalled);

        if (!defined('WP_UNINSTALL_PLUGIN')) {
            die;
        }
        
    }

    public function delete_tables() {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}lrotp");   
    }
}