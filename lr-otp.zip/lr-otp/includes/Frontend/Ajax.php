<?php
namespace LR\Otp;
/**
 * The Ajax class
 */
class Ajax {
    protected $error_message=[];
    protected $userdata=[];
    /**
     * Initializes the class
     */
    function __construct() {
        add_action( 'wp_ajax_lrotp_insert', [ $this, 'submit_lrotp'] );
        add_action( 'wp_ajax_nopriv_lrotp_insert', [ $this, 'submit_otp'] );

    }
    public function submit_lrotp() {
        global $wpdb;
        if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'new-lrotp' ) ) {
            wp_send_json_error( [
                'message' => 'Nonce verification failed!'
            ] );
        }
        
    }

}