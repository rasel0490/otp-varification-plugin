<?php
namespace LR\Otp\Frontend;
/**
 * The Frontend class
 */
class LrFrontendShortcode {
    /**
     * Initializes the class
     */
    function __construct() {
        add_shortcode( 'lrotp-frontend-shortcode', [ $this, 'lrotpFrontendShortcode' ] );
        
    }

    /**
     * Shortcode handler class
     *
     * @param  array $atts
     * @param  string $content
     *
     * @return string
     */

    // The callback function that will replace 
    function lrotpFrontendShortcode( $atts, $content = '') {
        wp_enqueue_script( 'lrotp-script' );
        wp_enqueue_style( 'lrotp-style' );
       
        ob_start();
        include __DIR__ . '/views/lrotpfrontend.php';
        return ob_get_clean();
        }
}