<?php
namespace LR\Otp;
/**
 * The Frontend class
 */
class Frontend {

    /**
     * Initialize the class
     */
    function __construct() {
        new Frontend\LrFrontendShortcode();
        
        
    }



}