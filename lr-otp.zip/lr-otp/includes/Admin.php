<?php
namespace LR\Otp;
/**
 * The admin class
 */
class Admin {

    /**
     * Initialize the class
     */
    function __construct() {
        new Admin\Menu();
        new Admin\LrotpDashboardShortcode();
        new Admin\LrotpSettingsShortcode();
        
    }



}