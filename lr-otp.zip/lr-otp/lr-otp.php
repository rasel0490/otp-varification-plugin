<?php
/**
 * Plugin Name: LR OTP Varification
 * Description: LR OTP Varification plugin.
 * Plugin URI: https://linereflection.com/otp-varification
 * Author: Rasel Ahsan
 * Author URI: https://www.raselahsan.com/
 * Version: 1.0
 * License: GPL2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
require_once __DIR__ . '/vendor/autoload.php';
/**
 * The main plugin class
 */
final class LR_otp {
    /**
     * Plugin version
     *
     * @var string
     */
    const version = '1.0';
    /**
     * Class construcotr
     */
    private function __construct() {
        $this->define_constants();

        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
        add_action( 'plugins_loaded', [ $this, 'init_plugin' ] );
        
    }
    /**
     * Initializes a singleton instance
     *
     * @return \LR_otp
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new self();
        }

        return $instance;
    }
    /**
     * Define the required plugin constants
     *
     * @return void
     */
    public function define_constants() {
        define( 'LR_OTP_VERSION', self::version );
        define( 'LR_OTP_FILE', __FILE__ );
        define( 'LR_OTP_PATH', __DIR__ );
        define( 'LR_OTP_PLUGIN_DIR', plugin_dir_path(__FILE__));
        define( 'LR_OTP_URL', plugins_url( '', LR_OTP_FILE ) );
        define( 'LR_OTP_ASSETS', LR_OTP_URL . '/assets' );
        define( 'LR_OTP_INCLUDES', LR_OTP_URL . '/includes' );
        
    }
    /**
     * Initialize the plugin
     *
     * @return void
     */
    public function init_plugin() { 

        new LR\Otp\Assets();
        
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            new LR\Otp\Ajax();
            
        }

        
        if ( is_admin() ) {
            new LR\Otp\Admin();
        } else {
             new LR\Otp\Frontend();
            
            
        }

    }
    /**
     * Do stuff upon plugin activation
     *
     * @return void
     */
    public function activate() {
        $installer = new LR\Otp\Installer();
        $installer->run();
    }
    /**
     * Do stuff upon plugin deactivation
     *
     * @return void
     */
    public function deactivate() {
        //$deactivator_plugin = new LR\Otp\Deactivator();
        //$deactivator_plugin->uninstall();
        
    }
}
/**
     * Initializes the main plugin
     *
     * @return \LR_otp
     */
    function lr_otp() {
        return LR_otp::init();
    }

    // kick-off the plugin
    lr_otp();