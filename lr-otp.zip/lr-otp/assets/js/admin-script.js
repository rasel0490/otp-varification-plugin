jQuery(document).ready(function($) {
  
    alert('ok');
  });